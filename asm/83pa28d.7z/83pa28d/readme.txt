===============================================================================================
= Learn TI-83 Plus Assembly In 28 Days v2.0 ReadMe File                                       =
===============================================================================================

This file contains information on properly viewing the associated HTML documents.

================
= INSTALLATION =
================
IF YOU ARE UPGRADING FROM VERSION 1.1 AND EARLIER, DELETE AND RE-INSTALL EVERYTHING.

Extract everything to a directory of your choosing. I recommend "C:\asm\tut\".
Do not delete or move any of the files after decompressing.
That's it. Open "welcome.html" to begin.

===========
= VIEWING =
===========
Learn TI-83 Assembly In 28 Days v2.0 will display correctly with
Internet Explorer 5+ (Windows) - Definitely
Internet Explorer (Mac) - 99%
Safari (Mac) - 99%
Mozilla and Opera - I hope so... :)

For maximum clarity, your browser window should be maximized while viewing the lessons, and the
dimensions of your monitor set to a minimum of 800x600.

===============================================================
= COPYRIGHT, TRADEMARKS, AND COPYING/DISTRIBUTING INFORMATION =
===============================================================
See the COPYRIGH.TXT file that comes with TASM for copyright information about TASM.

TI83PLUS.INC file and TI-83 Plus graphing calculator are (C) 1999 Texas Instruments.

Copyright (c)  2002, 2003, 2004 Sean McLaughlin.

Permission is granted to copy, distribute and/or modify this document under the terms
of the GNU Free Documentation License, Version 1.2 or any later version published by
the Free Software Foundation; with the Invariant Sections being just "Welcome", no
Front-Cover Texts, and no Back-Cover Texts.  A copy of the license is included in the
section entitled "GNU Free Documentation License".

You should have received a copy of the GNU Free Documentation License as "GFDL.HTML".
If you did not, or for whatever reason cannot read hypertext markup language, write to

      Free Software Foundation
      59 Temple Place - Suite 330
      Boston, MA 02111-1307
      USA
